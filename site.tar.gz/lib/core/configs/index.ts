const configs = {
  settings: {
    currency: 'BRL',
    locale: 'pt-BR',
  },
}

export default configs
